import React, {useState, useEffect} from 'react';

const FindId = () => {
    return (
        <div>FindId Page 입니다.</div>
    )
};

export default FindId;